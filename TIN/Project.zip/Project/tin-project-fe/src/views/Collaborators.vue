<script setup lang="ts"></script>

<template>Collabs</template>

<style scoped></style>
